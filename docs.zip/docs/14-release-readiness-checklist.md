# 开发和发布准入清单

清单项必须附 PR、测试结果、评测报告或运行记录；口头确认不算完成。

## Architecture Freeze Gate

- [x] 统一领域语言并区分 Source、Candidate、Version、Head、Projection、Context；
- [x] 记录 Authority before Index、Ledger、最终一致投影和读取权限交集 ADR；
- [x] 禁止 `extract_and_store` 作为正式写入原语；
- [x] 定义写入、修正、争议、Forget、Erasure 和重建流程；
- [x] 定义数据表职责、事务边界和数据库不变量；
- [x] 定义 Provider 与 Context Pack 契约；
- [x] 定义安全、故障、评测、测试、SLO 和运行基线；
- [ ] 架构与安全评审通过；
- [ ] ADR-0001 的 Mem0 POC 结果完成评审。

## POC Gate

- [x] 固定 Mem0 OSS source commit、本地镜像 digest 和实际 OpenAPI 契约；
- [x] 用领域类型和 `infer=false` Adapter 证明 Candidate 与正式 Projection 写入隔离；
- [ ] Rust spike 完成 extract/upsert/search/delete/health；
- [ ] 中文、关键词、更新、冲突、删除和隔离 smoke 数据集跑通；
- [x] Provider 超时、重启、unknown result 和幂等行为有证据（结果证明 Mem0 本身不提供 operation-level idempotency）；
- [ ] 从 `memory_core` 全量重建新 generation 成功；
- [x] 数据外发、日志和遥测边界已确认（`infer=false` 仍向 Embedder 发送正文；合成本地 POC 使用 hash-only Embedder 并关闭遥测）；
- [ ] 记录资源、延迟、token、成本和已知限制；
- [ ] 根据证据接受、修订或拒绝 ADR-0001。

## MVP Development Gate

- [ ] OpenAPI/事件契约通过 lint 和契约测试；
- [ ] PostgreSQL Migration、RLS、复合外键和 append-only 权限完成；
- [ ] Candidate/Decision/Ledger/Head/Outbox Repository 完成；
- [ ] Policy reason codes、Review API 和 typed Scope 完成；
- [ ] 并发单赢家、幂等和事务回滚测试通过；
- [x] Provider Adapter 契约测试通过；
- [ ] Context Pack、Usage Receipt 和 invalidation 完成；
- [ ] Forget/Tombstone/Erasure/重放测试通过；
- [ ] 所有领域不变量与测试建立映射；
- [ ] Agent Runtime 只通过 Memory API/port 集成。

## Demo v0 Gate

- [x] 明确 `请记住` 请求能确定性生成低风险 Preference Candidate；
- [x] Source/Candidate/Decision/Version/Event/Head/Outbox 在一个 PostgreSQL 事务中提交；
- [x] 相同 Idempotency-Key 返回相同 canonical Operation；
- [x] Outbox Worker 实现 lease/fencing、Head/Tombstone 复查和 Provider reconciliation；
- [x] Search 仅使用 Mem0 返回的映射字段，并从 PostgreSQL 加载和授权 canonical 正文；
- [x] Forget 提交后由 Head/Tombstone 立即阻断读取，并异步删除 Provider Projection；
- [x] `scripts/demo-v0.sh` 覆盖 remember/idempotency/ready/search/forget/deleted；
- [x] 最新代码在全新 PostgreSQL + 固定 Mem0 runtime 上完成端到端演示验收（2026-07-27，`scripts/demo-v0.sh` 连续两次通过）。

## Demo Agent v1 Gate

- [x] 独立 `demo-agent` 仅通过 Memory API 访问 canonical memory，并通过 Kimi Code OpenAI 兼容协议调用 `k3`；
- [x] Kimi 官方 Base URL 和 `k3` 被显式约束，API Key 只从非空环境变量读取，错误与输出不包含 Key；
- [x] 新 Task/Attempt 通过服务端 Context Pack API 获取 PostgreSQL 同事务重新授权的 Preference；
- [x] Agent 将 Context Pack item 编码为未信任用户数据，并限制其只能影响回答风格；
- [x] Forget 提交后立即确认目标 Memory 不可读，再发起不含该记忆的新 Task/Attempt，并等待 Provider Projection 删除；
- [x] `scripts/demo-agent-v1.sh` 预检 Key 和 Memory Service，就绪后优先运行 Cargo binary；
- [x] 使用本地确定性 Chat Completions 假服务完成完整 HTTP 编排验收，并证明 `memory_context_count` 从 1 变为 0；
- [x] 使用已轮换的真实 Kimi Key 完成端到端运行验收，并保存不含凭据的运行证据（2026-07-28）；
- [x] Demo Context Pack API、确定性预算、Usage Receipt 和 Forget invalidation 已替换客户端选择逻辑，并完成本地端到端验收（2026-07-28）；
- [x] 服务端 Context Pack 改造后再次完成真实 Kimi `k3` 回归，并核验 Pack/Receipt/失效数据库证据（2026-07-28）；
- [x] 本地 Web 演示台通过“记住、用上、忘掉”向非技术观众展示真实链路，浏览器不接触 Kimi Key；
- [x] Web API 使用 loopback、受限 CORS 和单飞锁，并通过本地假模型端到端验收（2026-07-28）；
- [ ] 补齐消费前原子校验、正式 tokenizer/reranker、Pack 签名、Outcome Receipt 和 Policy/ACL/Consent 全量失效；
- [ ] LazyTT Agent Runtime 完成正式 Memory API/port 集成并通过独立契约与端到端测试。

## Production Gate

- [ ] 固定评测集达到已批准阈值且优于 no-memory baseline；
- [ ] 跨 Tenant/Project、Secret、Stale/Deleted 注入均为 0；
- [ ] 威胁模型和隐私评审通过；
- [ ] 负载、Provider 降级、backlog 和重建压测完成；
- [ ] SLO、告警、dashboard 和值班处理人明确；
- [ ] Backup/PITR、Tombstone replay 和投影重建演练完成；
- [ ] RPO/RTO 有实际演练数据；
- [ ] Migration、canary、rollback 和 incident runbook 演练完成；
- [ ] 数据导出、Forget、Erasure 端到端验收通过；
- [ ] SBOM、镜像签名、漏洞和 secret scan 通过；
- [ ] 发布负责人签署 Production Readiness Review。

## 自动阻断条件

出现以下任意情况不得上线：

- Mem0/Provider 仍被当作权威数据源；
- Candidate/NeedsReview 内容能进入正式 Context；
- Memory 能影响 ACL、Approval 或工具权限；
- 跨租户、Secret、Forgotten/Erased 内容出现一次；
- 无法从 Ledger 重建 Head/Projection；
- 删除依赖 Provider 在线才能阻止读取；
- 只有指标名称，没有评测数据集、阈值或原始报告；
- 未完成恢复演练却声称可生产运行。
