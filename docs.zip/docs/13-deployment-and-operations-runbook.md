# 部署与运行手册

## 环境与组件

```text
memory-api             无状态在线服务
memory-worker          Outbox、投影、过期、擦除、对账
postgresql             memory_core / memory_search
mem0                   候选 Provider，私网访问
telemetry backend      metrics/logs/traces
secret/key service     Provider credentials and encryption keys
```

本地、测试、生产使用相同镜像和 Migration，配置与资源不同。生产镜像固定 digest，生成 SBOM，并保留 Provider/模型版本清单。

## 配置基线

- Mem0 不暴露公网；
- API/Worker 使用不同数据库角色；
- RLS 开启且应用角色不能 bypass；
- Secret 从 Secret Manager 注入，不写配置文件；
- Provider egress 使用 allowlist；
- 每 Tenant 配额、请求大小和并发限制；
- 日志脱敏和正文采样默认关闭；
- 所有版本和 Policy/Compiler generation 显式配置。

## 健康检查

- `/health/live`：进程事件循环可用，不依赖 Provider；
- `/health/ready`：数据库、Migration 版本、Authority 配置可用；
- Provider 故障反映在 capability 状态和指标中，普通 API MAY 保持 ready 并降级；
- 当权威数据库或 Policy 不可用时必须 not ready。

## Migration

采用 expand → backfill → dual-read/write（需要时）→ verify → contract：

1. 新增向后兼容结构；
2. 部署可兼容新旧结构的应用；
3. 有界批量回填并对账；
4. 切换读取；
5. 观察至少一个发布窗口；
6. 删除旧结构。

DDL 回滚不是默认恢复方案；每次 Migration 必须有前滚修复、备份点和兼容性说明。

## 备份与恢复

- PostgreSQL 启用加密备份和 PITR；
- Tombstone/Erasure journal 的恢复点不得早于主库；
- 每个发布周期执行恢复演练；
- 恢复后先回放 Tombstone，再重建投影，最后开放服务；
- 记录实际 RPO、RTO、丢失/重复操作和人工步骤。

## 常用运行流程

### Provider 故障

1. 确认 Authority/DB 正常；
2. 打开熔断，停止新外部调用；
3. Context 降级为空或本地 FTS；
4. 观察 Outbox backlog 和磁盘容量；
5. Provider 恢复后限速重放；
6. 运行 hash/孤儿对账。

### Projection 重建

按照 [流程文档](./04-write-read-correct-forget-flows.md) 创建新 generation、校验、切换，禁止原地覆盖唯一线上索引。

### Erasure 卡住

1. Authority Head 保持 Forgotten/Erased，不允许恢复读取；
2. 定位未完成 handler；
3. 使用相同 erasure/operation ID 重试；
4. deadline 前无法完成则升级安全事件；
5. 完成后生成不含正文的 Receipt。

### DLQ 重放

必须先确认根因和当前 Head/Tombstone。重放使用原 operation ID 或明确的新 repair operation，并保留关联关系；不得批量无条件重新 upsert。

## 发布和回退

- 先测试环境跑完整契约/评测/恢复；
- Canary 按 Tenant 隔离，监控安全与质量指标；
- 应用回退必须保持新旧 Schema 兼容；
- Provider generation 切换可独立回退；
- 出现越权、Secret escape、Tombstone resurrection 时立即停止相关能力，而不是仅降低流量。
