# 写入、读取、修正和遗忘流程

## 通用事务原则

推进 Memory Record 的唯一事务形态是：

```text
Lock → Guard → Decide → Append → Reduce → Outbox → Commit
```

- `Lock`：按 `(tenant_id, memory_record_id)` 加锁或校验 `expected_revision`；
- `Guard`：重新验证身份、Scope、Consent、Policy、状态和 Tombstone；
- `Decide`：产生确定性的领域结果；
- `Append`：追加 Version、Decision 和 Memory Event；
- `Reduce`：更新 Memory Head 读取投影；
- `Outbox`：写入幂等投影操作；
- `Commit`：一次提交。

模型、Mem0、消息发送和对象存储调用必须在事务外。

## 1. Source Event 与候选写入

```mermaid
sequenceDiagram
    participant R as Agent Runtime
    participant A as Memory API
    participant P as Policy
    participant D as PostgreSQL
    participant E as Extractor
    participant W as Worker
    participant I as Retrieval Index

    R->>A: POST event + Idempotency-Key
    A->>P: authenticate, derive scope, classify
    P-->>A: deny or allow extraction
    A->>D: persist sanitized source envelope
    A->>E: extract candidates, no durable indexing
    E-->>A: untrusted candidate proposals
    A->>P: deterministic validation
    A->>D: append candidate/decision/version/event/head/outbox
    D-->>A: commit accepted, projection pending
    A-->>R: operation_id + canonical status
    W->>D: lease outbox operation
    W->>I: idempotent upsert accepted version
    I-->>W: projection receipt
    W->>D: mark projection ready
```

### 响应语义

- `202 accepted_for_processing`：Source Event 已幂等接收，候选尚未最终决定；
- `200 candidate_rejected`：已决定不形成正式记忆；
- `200 needs_review`：等待人工审核，不得索引；
- `201 memory_accepted`：Version 与 Head 已提交，投影可能仍为 Pending；
- `projection_ready` 只能通过 operation 查询或后续事件确认。

禁止用一个含糊的 `accepted` 同时表达“HTTP 已接收”“Candidate 已接受”和“索引已可检索”。

## 2. 人工审核

1. 审核者必须具有 Candidate 所在 Tenant/Scope 的 review 权限；
2. API 携带 `expected_candidate_revision` 和幂等键；
3. 重新执行当前 Policy，而不是沿用创建 Candidate 时的授权；
4. Accept 时在一个事务内追加 Decision、Memory Version、Ledger Event、Head 和 Outbox；
5. Reject 时只追加最终 Decision 和审计，不创建正式投影。

## 3. 检索与 Context 编译

```mermaid
sequenceDiagram
    participant R as Agent Runtime
    participant A as Memory API
    participant G as Authority Gateway
    participant I as Retrieval Index
    participant D as PostgreSQL
    participant C as Context Compiler

    R->>A: compile(attempt, purpose, query, budget)
    A->>G: derive authorized scope set
    G-->>A: authority snapshot + allowed scopes
    A->>I: search only allowed scope partitions
    I-->>A: projection hits
    A->>D: map version IDs and load current heads
    A->>G: re-check scope/purpose/consent/policy
    G-->>A: allowed versions + reason codes
    A->>C: rank, dedupe, budget, quote safely
    C->>D: persist context pack and receipts
    C-->>R: immutable attempt-bound pack
```

要求：

- Provider 不可用时 MAY 使用本地 FTS 精确检索；没有合法结果时返回空 Pack；
- 对声明 `memory_required=true` 的 Task，无法完成权威检查时返回 `MEMORY_UNAVAILABLE`，不得静默继续；
- 权限不确定、版本陈旧、争议或已遗忘一律省略；
- Agent Runtime 重试 Attempt 时必须重新编译。

## 4. 修正

请求必须包含 `expected_revision`、reason、来源和幂等键。

```text
load and lock Head
→ re-authorize actor
→ reject if expected_revision mismatches
→ append new immutable Version
→ append MemoryCorrected event
→ move Head to new Version and increment revision
→ enqueue delete/upsert projection operations
→ commit
```

旧 Version 不修改。旧索引删除与新索引 upsert 使用同一个 ordering key；Worker 在执行前读取 Head，避免旧操作覆盖新版本。

## 5. 争议解决

- 无法自动判断的冲突追加 `MemoryContested`，Head 状态变为 `Contested`；
- Contested 默认不进入 Context；
- 审核者选择现有 Version 或追加新 Version 后，追加 `MemoryContestResolved`；
- 解决操作使用 `expected_revision`，并重建该 Record 的投影。

## 6. Forget 与 Erasure

### Forget：立即停止使用

```text
authorize
→ append MemoryForgotten
→ Head = Forgotten, revision + 1
→ write Tombstone
→ enqueue projection/cache invalidation
→ commit
```

事务提交后，权威读取必须立即拒绝该记录，即使 Provider 删除尚未完成。

### Erasure：删除受管内容

Erasure 是可跟踪工作流：

1. 创建 `erasure_request`；
2. Forget 并写 Tombstone；
3. 删除 Provider/FTS/vector/cache 投影；
4. 清除允许擦除的 Source excerpt、Version content、Context content 和导出副本；
5. 记录各处理器 Receipt；
6. 完成后 Head 标记 Erased，仅保留允许保留的不可识别审计事实。

备份中的删除遵循文档化保留期；恢复备份时必须先回放 Tombstone/Erasure 日志再开放服务。

## 7. 投影重建

1. 为 Tenant 建立 rebuild generation；
2. 读取当前 Active Head 和合法 Version；
3. 排除 Contested、Expired、Forgotten、Erased 和 Tombstone；
4. 写入隔离的新 generation；
5. 对比数量、hash 和抽样查询；
6. 原子切换读取 generation；
7. 清理旧 generation。

重建不得从聊天记录、旧 Provider 索引或 Candidate 反向生成正式记忆。
