# 目标、边界和成熟度

## 目标

LazyTT Memory System 为 Agent Runtime 提供跨会话长期记忆：从有来源的事件中提出候选，经确定性治理后保存版本化记录，按当前权限检索，并为单次 Attempt 编译可追溯的 Memory Context Pack。

第一阶段服务以下场景：

- 用户明确表达的长期偏好；
- 稳定用户资料和项目事实；
- 与当前任务相关的已验证历史经验；
- 记忆修正、争议、过期、遗忘、导出和检查；
- Tenant、User、Project 和 Agent 作用域隔离。

## 非目标

第一阶段不负责：

- Canonical Business State、Task/Attempt Runtime State；
- 身份、ACL、Consent 或工具权限的权威存储；
- 从记忆自动授予执行权；
- 自动发布 Procedure/Skill；
- 完整时间知识图谱、自动 Reflection 和复杂关系推理；
- 用聊天记录或向量数据库替代可审计的 Memory Ledger。

## 系统承诺

系统只承诺“在证据、Policy 和当前 Authority 允许范围内，提供可能有帮助的长期信息”。它不承诺记忆永远正确，因此必须支持来源、置信度、冲突、有效期、修正和不注入。

关键边界：

```text
Canonical State 决定真实业务状态
Authority 决定允许读取与执行什么
Memory Ledger 保存已接受的长期信息
Retrieval Projection 加速查找
Memory Context Pack 服务一次 Attempt
```

## 当前成熟度

当前状态为 `Architecture Baseline / Pre-POC`：

- 允许：实现 Provider spike、Migration 原型、契约测试和固定评测集；
- 不允许：宣称 MVP 已完成、接入生产用户数据或把 Mem0 当权威数据库；
- ADR-0001 在 POC 通过前保持 `proposed`。

阶段状态以 [发布准入清单](./14-release-readiness-checklist.md) 为唯一判断依据，不以“接口已经能返回结果”作为完成标准。
