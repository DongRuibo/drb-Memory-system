# 安全、隐私与威胁模型

## 安全目标

- Tenant、User、Project、Agent 之间不发生越权读取或写入；
- 模型、Provider 和记忆正文不能授予 Authority；
- Secret 和未授权敏感个人信息不进入 Extractor、日志或索引；
- Forget/Erasure、Consent 撤销和成员关系变化可确定传播；
- 所有管理、审核、导出和擦除操作可追溯。

## 数据分类

| 分类 | 默认处理 |
|---|---|
| Public | 可按明确 Scope 保存 |
| Internal | 需要 Tenant 身份和 Purpose |
| Personal | 需要主体/业务依据、Retention 和导出/删除能力 |
| Sensitive | 默认 NeedsReview，强加密和最小化 |
| Secret | 禁止写入、禁止发送 Provider，触发安全审计 |

分类在调用外部 Extractor 前完成。日志、Trace 和错误信息不得复制 Personal/Sensitive/Secret 正文。

## 身份与授权

- 外部 API 使用短期服务/用户身份令牌；
- Runtime 请求必须携带可验证的 Task/Attempt 归属；
- Scope 和 principal 从认证上下文派生，不能信任请求体；
- 管理、Review、Export、Forget、Erasure 使用独立 permission；
- PostgreSQL RLS 作为应用校验之外的第二道边界；
- Authority snapshot 有短 TTL，Resume/Retry 必须重新验证。

## 主要威胁与控制

| 威胁 | 示例 | 必须控制 |
|---|---|---|
| 跨租户检索 | Provider filter 失效 | Provider 前置收窄 + canonical mapping + RLS + 安全测试 |
| Memory poisoning | 网页/工具输出要求保存恶意规则 | 来源等级、显式/推断区分、Policy/Review、不得授予权限 |
| Prompt Injection | 记忆内容要求忽略系统指令 | 作为引用数据封装、trust 标记、禁止工具参数直通 |
| Secret exfiltration | Token 被送入外部模型 | 本地 secret scan、拒绝、日志脱敏、Provider egress allowlist |
| Stale authorization | 用户离开项目后旧索引仍命中 | 每次读取权威复核、短 TTL、fail closed |
| Replay resurrection | 旧 Outbox 恢复已删除内容 | revision、Tombstone、generation、幂等 operation ID |
| Insider abuse | 管理员批量导出 | 最小权限、双人审批可配置、审计、限流和告警 |
| Dependency compromise | Mem0 镜像或模型 SDK 被篡改 | 固定版本、镜像签名/SBOM、漏洞扫描、隔离网络 |
| Denial of service | 超长 Source/大量写入 | 大小限制、租户配额、背压、超时、熔断 |

## Prompt Injection 处理

记忆正文永远是 untrusted data。Context Compiler 必须：

- 使用稳定分隔和引用格式；
- 不把记忆正文放入 system policy 区；
- 不从正文解析权限、工具名或执行参数；
- 对程序性文本只生成 Procedural Candidate；
- 在高风险工具调用前由 Runtime 重新执行 Policy，与 Memory Pack 无关。

## 数据最小化与加密

- Source 默认保存 hash、引用和最小摘录，不复制完整聊天；
- Personal/Sensitive 内容字段使用应用层 envelope encryption 或等价控制；
- Key 按环境隔离并支持轮换；
- Provider 只获得检索所需的最小正文和 metadata；
- 备份加密，恢复权限与生产写权限分离。

## Forget、Erasure 与导出

- Forget 提交后立即从权威读取集合移除；
- Erasure 必须覆盖 Version content、Source excerpt、Provider/FTS/vector、cache 和可控 Context 快照；
- 审计仅保留政策允许的非识别 ID/hash；
- 导出按当前 Authority 重新过滤，不包含其他主体或内部 Provider 字段；
- 备份删除窗口、法律保留和恢复后 tombstone replay 必须写入运行手册。

## 安全发布门槛

- 跨租户/跨项目矩阵测试 100% 通过；
- Secret corpus 进入 Provider/日志的数量为 0；
- 旧索引、撤权、Forget、Erasure 重放测试全部通过；
- Prompt Injection 测试不能改变 Authority 或直接形成工具调用；
- 高危依赖漏洞为 0，并完成威胁模型评审。
