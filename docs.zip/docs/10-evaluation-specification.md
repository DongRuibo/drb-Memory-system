# 评测规范

评测用于回答四个问题：该不该记、记得是否正确、能否在需要时找回、是否实际帮助 Agent 且不造成伤害。

## 数据集

评测集必须版本化，并为每条样本保存输入、Scope、时间、预期 Candidate/Decision、允许读取者、预期当前事实和禁止行为。

首个 MVP 数据集 SHOULD 覆盖：

- 明确偏好、隐式偏好、临时信息；
- 稳定项目事实、事实更新、时间范围、冲突；
- 精确关键词、中文同义表达、无关相似文本；
- Secret、第三方 PII、Prompt Injection；
- Tenant/User/Project/Agent 隔离；
- 修正、Forget、Erasure、撤权和旧索引；
- Provider 超时、重复事件和并发更新；
- Procedural Candidate 不自动执行。

20～50 条只用于 smoke POC；MVP gate 使用的固定集必须足以覆盖上述每一类别的正例和负例，并报告置信区间或样本数量，不能只报告总平均。

## 对照组

每次效果评测至少比较：

1. no-memory baseline；
2. local exact/FTS baseline；
3. 当前 Provider；
4. oracle context 上界。

Provider 更换、模型/Embedding/Reranker/Prompt/Policy 版本变化必须跑同一数据集。

## 指标定义

### 写入

- `Write Precision = 正确接受 / 全部接受`；
- `Write Recall = 应接受且被接受 / 全部应接受`；
- `False Memory Rate = 错误或无来源接受 / 全部接受`；
- `Secret Escape Rate = 进入 Provider 或正式存储的 Secret / Secret 样本`；
- Duplicate、Incorrect Update、Conflict Detection 分类别报告。

### 检索与 Context

- Recall@K、MRR、nDCG；
- Current Fact Accuracy；
- Relevant/Irrelevant Injection Rate；
- Stale/Contested Injection Rate；
- Scope Isolation Accuracy；
- Token efficiency：有效注入 token / 总记忆 token。

### Agent 结果

- Task Success delta 相对 no-memory；
- Memory Helpful/Harm Rate；
- Citation/Source correctness；
- Unauthorized action delta 必须为 0。

## MVP 建议门槛

正式数值在 POC 基线后由团队批准并写入本节。批准前以下是不可协商门槛：

- 跨 Tenant/Project 越权召回：0；
- Secret Escape：0；
- Forgotten/Erased/Stale Version 注入：0；
- Memory 导致权限提升或自动执行：0；
- 所有注入项具备可解析的 Version 和 Source 引用：100%。

其余质量指标不得写“效果良好”，必须记录数据集版本、样本数、模型/Provider 版本、原始结果和阈值。

## 评测产物

每次发布保留：

```text
evaluation-manifest.json
dataset-version
system/provider/model versions
metric-results.json
failure-cases.jsonl
comparison-report.md
```

LLM Judge 只能辅助评分；关键安全、Scope、版本、删除和来源正确性必须由确定性断言判断。
